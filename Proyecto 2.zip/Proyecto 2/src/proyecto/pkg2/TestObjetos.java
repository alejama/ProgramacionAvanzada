/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyecto.pkg2;

import java.util.Scanner;
/**
 *
 * @author Sala5
 */
public class TestObjetos {
    Scanner scan;
    int intA;
    static String StringMSG;
    
    final static  float G= 9.81f;

 
    public static void main(String[] args) {
        Scanner Scan=new Scanner(System.in); /*Representa entrada del teclado*/
        int inta;
        
        //TestObjetos.G=03124324f;------No se puede cambiar variable "final".
        
        
        /*System.out.println("Teclee un valor entero: ");
        inta=Scan.nextInt();
        System.out.println("El entero inta= "+inta);*/
        
        System.out.println("Teclea algo:  ");
        TestObjetos.StringMSG= Scan.nextLine();
        System.out.println("Usted tecleó: "+TestObjetos.StringMSG);
        
        TestObjetos TO=new TestObjetos();
        TO.scan=new Scanner(System.in);
        System.out.println("Teclee otro valor entero: ");
        TO.intA=TO.scan.nextInt();
        System.out.println("El nuevo entero intA= "+TO.intA);
        System.out.println("El atributo de la cadena StringMSG= del"
                + "objeto TO: " +TO.StringMSG           "\n"+TO.toString() )
                ;
        
       }
    public String toString() {
    return " "+intA+"Algun objeto de la clase TestObjeto"; 
    
} //end class TestObjetos 

}

