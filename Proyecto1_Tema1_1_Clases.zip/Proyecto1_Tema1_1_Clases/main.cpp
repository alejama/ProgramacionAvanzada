#include <cstdlib>
#include <iostream>
#include <stdio.h> //sprintf();

using namespace std;

/*
*Clase para representar Notas de recordatorio
*o posiblemente notas de pie de pagina. En fin.
*Una nota que podriamos anotar por ejemplo en un post it
*Esta clase tambien muestra como podemos declarar 
*Clases sin selecciones privadas.
*/


struct NOTA{
       
       int intFecha;  
       string stringFecha;
       string stringContenidoDeNota;
       string stringDestinatario;
       string stringRemitente;
       
       void mostrar(){
                      cout<<stringFecha<<endl;
                      cout<<"Para: "<<stringDestinatario<<endl;
                      cout<<"De: "<<stringRemitente<<endl;
                      cout<<stringContenidoDeNota<<endl;            
            }
          };



int main(int argc, char *argv[])
{
    NOTA Nota;
    
    Nota.intFecha=20180810;
    char str[20];
    sprintf(str,"%d",Nota.intFecha);
    
    Nota.stringFecha=string(str);
    
    Nota.stringRemitente="Remitente";
    Nota.stringDestinatario="Destinatario";
    Nota.stringContenidoDeNota="\nWenas tardes";
    
    Nota.mostrar();
    
    system("PAUSE");
    return EXIT_SUCCESS;
}
