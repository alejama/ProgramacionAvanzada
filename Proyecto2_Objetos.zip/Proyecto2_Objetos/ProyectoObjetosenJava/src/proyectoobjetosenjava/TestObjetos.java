/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectoobjetosenjava;

import java.util.Scanner;

/**
 *
 * @author Sala5
 */
public class TestObjetos {
    Scanner scan;
    int intA; /*Declara variable */
    static String stringMSG;
    final static float G=9.81f; /* m/s^2, gravdad CONSTANTE VARIABLE DE CLASE*/
    public static void main(String[] args) {
        Scanner Scan=new Scanner(System.in); /*new para iniciar, in para obtener entrada del teclado */
        int inta;
        TestObjetos.G = 9.9f;
        /*System.out.println("Teclee un valor entero: ");
        inta = Scan.nextInt();
        System.out.println("El entero inta = "+inta);
        */
        System.out.println("Teclee algo: ");
        TestObjetos.stringMSG = Scan.nextLine();
        System.out.println("Usted tecleo: "+TestObjetos.stringMSG); 
        
        TestObjetos TO = new TestObjetos(); /*Para poder hacer estatico*/
        
        
        TO.scan = new Scanner(System.in);
        System.out.println("Teclee otro valor entero: ");
        TO.intA = TO.scan.nextInt();
        System.out.println("El entero inta = "+TO.intA);
        System.out.println("El atributo StringMSG del "
                + "objeto TO: "+TO.stringMSG+"\n"+TO.toString());
    }
    public String toString(){
        return ""+intA+"Algun objeto de clase TestObjetos";
    }
    
}//end class TestObjetos
