#include <cstdlib>
#include <iostream>

using namespace std; 
#define ARCHIVO.txt c:/users/Sala5/archivo.txt //respaldo de datos
int main(int argc, char *argv[])
{
	cout<<"Que pedo wey"<<endl;
	system("PAUSE");
    return EXIT_SUCCESS;
}
